const task = (n) => {
    return (2 ** n) - 1;
};


// console.log(task(1));
// console.log(task(2));
// console.log(task(3));
// console.log(task(4));
// console.log(task(5));
// console.log(task(6));
// console.log(task(7));
// console.log(task(8));